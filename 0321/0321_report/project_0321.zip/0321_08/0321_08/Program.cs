﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0321_09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("원의 중심과 반지름 입력>>");
            string pp1 = Console.ReadLine();
            double p1 = Convert.ToDouble(pp1);
            string pp2 = Console.ReadLine();
            double p2 = Convert.ToDouble(pp2);
            string rr = Console.ReadLine();
            double r = Convert.ToDouble(rr);

            Console.WriteLine("점 입력>>");
            string xx = Console.ReadLine();
            double x = Convert.ToDouble(xx);
            string yy = Console.ReadLine();
            double y = Convert.ToDouble(yy);

            double distance = Math.Sqrt((x - p1) * (x - p1) + (y - p2) * (y - p2));
            if(distance < r)
            {
                Console.WriteLine("점(" + x + ", " + y + ")은 원 안에 있다.");
            }
        }
    }
}
