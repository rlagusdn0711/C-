﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rand= new Random();
            String[] str = { "가위", "바위", "보" };
            Console.WriteLine("컴퓨터와 가위 바위 보 게임을 합니다.");

            while (true)
            {
                Console.WriteLine("가위 바위 보! >> ");
                String userInput = Console.ReadLine();
                if (userInput=="그만")
                {
                    Console.WriteLine("게임을 종료합니다...");
                    break;
                }
                int cmp = rand.Next(3);
                String cmpOutput = str[cmp];
                Console.WriteLine("사용자 = " + userInput + " 컴퓨터 = " + cmpOutput);
                if (userInput==cmpOutput)
                    Console.WriteLine(", 비겼습니다.");

                else if (userInput=="가위" && cmpOutput=="보" || userInput=="보" && cmpOutput=="바위" || userInput=="바위" && cmpOutput=="가위")
                    Console.WriteLine(", 사용자가 이겼습니다.");

                else
                    Console.WriteLine(", 컴퓨터가 이겼습니다.");
            }
        }
    }
}
