﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            string alpha=Console.ReadLine();
            char calpha = alpha[0];

            int cnt = (int)calpha - 97;

            for (int i = 0; i <= cnt; i++)
            {
                alpha = 'a';
                for (int j = 0; j <= cnt - i; j++, alpha++)
                {
                    Console.WriteLine(alpha);
                }
                Console.WriteLine();
            }
        }
    }
}
