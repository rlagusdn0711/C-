﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("정수를 입력하시오 >> ");
            string sntt=Console.ReadLine();
            int cnt=int.Parse(sntt);

            for (int i = 0; i < cnt; i++)
            {
                for (int j = 0; j < cnt - i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }
}
