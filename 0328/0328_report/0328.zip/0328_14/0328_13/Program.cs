﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String[] course = { "Java", "C++", "HTML5", "컴퓨터구조", "안드로이드" };
            int[] score = { 95, 88, 76, 62, 55 };

            while (true)
            {
                int scr = 0;
                Console.WriteLine("과목 이름 >> ");
                String search = Console.ReadLine();
                if (search=="그만")
                    break;
                for (int i = 0; i < course.Length; i++)
                {
                    if (course[i]==search)
                    {
                        scr = score[i];
                        Console.WriteLine(course[i] + " 의 점수는 " + score[i]);
                        break;
                    }
                }
                if (scr == 0)
                {
                    Console.WriteLine("없는 과목입니다.");
                    continue;
                }
            }
        }
    }
}
