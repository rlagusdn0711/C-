﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0404_04
{
    class Rectangle
    {
        private int x, y, width, height;

        public Rectangle(int x, int y, int width, int height)
        {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }
        public int square()
        {
            return width * height;
        }
        public void show()
        {
            Console.WriteLine("(" + x + ", " + y + ") 에서 크기가 " + width + " X " + height + "인 사각형 ");
        }
        public Boolean contains(Rectangle r)
        {
            if (this.x <= r.x && this.y <= r.y && this.square() >= r.square())
            {
                return true;
            }
            else return false;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {

            Rectangle r = new Rectangle(2, 2, 8, 7);
            Rectangle s = new Rectangle(5, 5, 6, 6);
            Rectangle t = new Rectangle(1, 1, 10, 10);

            r.show();
            Console.WriteLine("s의 면적은 " + s.square());
            if (t.contains(r)) Console.WriteLine("t는 r을 포함합니다.");
            if (t.contains(s)) Console.WriteLine("t는 s을 포함합니다.");
        }
    }
}
