﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0321_05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("정수 3개를 입력>>");
            string aa = Console.ReadLine();
            int a = Convert.ToInt32(aa);
            string bb = Console.ReadLine();
            int b = Convert.ToInt32(bb);
            string cc = Console.ReadLine();
            int c = Convert.ToInt32(cc);

            if ((a + b) < c || (a + c) < b || (b + c) < a)
            {
                Console.WriteLine("삼각형이 안됩니다.");
            }
            else
            {
                Console.WriteLine("삼각형이 됩니다.");
            }
        }
    }
}
