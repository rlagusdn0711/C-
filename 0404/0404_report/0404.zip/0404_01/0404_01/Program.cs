﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0404_01
{
    class TV
    {
        private String manufacturer;
        private int year;
        private int inch;

        public TV(String manufacturer, int year, int inch)
        {
            this.manufacturer = manufacturer;
            this.year = year;
            this.inch = inch;
        }
        public void showTV()
        {
            Console.WriteLine(manufacturer + "에서 만든 " + year + "년형 " + inch + "인치 TV");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            TV myTV = new TV("LG", 2017, 32);
            myTV.showTV();
        }
    }
}
