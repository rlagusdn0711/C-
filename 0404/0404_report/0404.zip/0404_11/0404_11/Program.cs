﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0404_11
{
    class Add
    {
        private int a;
        private int b;

        public void setValue(int x, int y)
        {
            a = x;
            b = y;
        }
        public int calculate()
        {
            return a + b;
        }
    }
    class Sub
    {
        private int a;
        private int b;

        public void setValue(int x, int y)
        {
            a = x;
            b = y;
        }
        public int calculate()
        {
            return a - b;
        }
    }
    class Mul
    {
        private int a;
        private int b;

        public void setValue(int x, int y)
        {
            a = x;
            b = y;
        }
        public int calculate()
        {
            return a * b;
        }
    }
    class Div
    {
        private int a;
        private int b;

        public void setValue(int x, int y)
        {
            a = x;
            b = y;
        }
        public int calculate()
        {
            return a / b;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("두 정수와 연산자를 입력하시오 >> ");
            string xx = Console.ReadLine();
            string yy = Console.ReadLine();
            int x=int.Parse(xx);
            int y=int.Parse(yy);
            string ooperator = Console.ReadLine();

            if (ooperator=="+") {
                Add add = new Add();
                add.setValue(x, y);
                Console.WriteLine(add.calculate());
            }

        else if (ooperator=="-") {
                Sub sub = new Sub();
                sub.setValue(x, y);
                Console.WriteLine(sub.calculate());
            }

        else if (ooperator=="*") {
                Mul mul = new Mul();
                mul.setValue(x, y);
                Console.WriteLine(mul.calculate());
            }

        else if (ooperator=="/") {
                Div div = new Div();
                div.setValue(x, y);
                Console.WriteLine(div.calculate());
            }
        }
    }
}
