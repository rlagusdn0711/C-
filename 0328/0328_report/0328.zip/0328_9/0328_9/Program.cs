﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            int rnd;
            int[,] Array = new int[4,4];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    rnd= rand.Next(11);
                    Array[i,j] = rnd;
                }
            }
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Console.Write(Array[i,j] + "\t");
                }
                Console.WriteLine("");
            }
        }
    }
}
