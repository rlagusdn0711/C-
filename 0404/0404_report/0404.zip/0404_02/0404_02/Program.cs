﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0404_02
{
    class Grade
    {
        int math, science, english;

        public Grade(int math, int science, int english)
        {
            this.math = math;
            this.science = science;
            this.english = english;
        }

        public int average()
        {
            return (math + science + english) / 3;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("수학, 과학, 영어 순으로 3개의 점수 입력 >> ");
            string math1 = Console.ReadLine();
            string science1 = Console.ReadLine();
            string english1 = Console.ReadLine();
            int math=int.Parse(math1);
            int science=int.Parse(science1);
            int english=int.Parse(english1);
            Grade me = new Grade(math, science, english);
            Console.WriteLine("평균은 " + me.average());
        }
    }
}
