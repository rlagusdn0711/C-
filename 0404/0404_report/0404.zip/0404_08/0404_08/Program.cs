﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0404_08
{
    class Phone
    {
        private String name;
        private String tel;

        public Phone(String name, String tel)
        {
            this.name = name;
            this.tel = tel;
        }
        public String getName()
        {
            return name;
        }
        public String getTel()
        {
            return tel;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Boolean condition = true;
            Console.Write("인원수 >> ");
            string cntt=Console.ReadLine();
            int cnt=int.Parse(cntt);
            Phone [] phone = new Phone[cnt];

            for (int i = 0; i < phone.Length; i++)
            {
                Console.Write("이름과 전화번호(이름과 전화번호는 빈칸 없이 입력) >> ");
                String name = Console.ReadLine();
                String tel = Console.ReadLine();
                phone[i] = new Phone(name, tel);
            }
            Console.WriteLine("저장되었습니다...");
            while (true)
            {
                Console.WriteLine("검색할 이름을 입력하세요 >> ");
                String searchName = Console.ReadLine();
                if (searchName=="그만") 
                    break;
                for (int i = 0; i < phone.Length; i++)
                {
                    if (phone[i].getName()==searchName)
                    {
                        Console.WriteLine(searchName + "의 번호는 " + phone[i].getTel() + "입니다.");
                        condition = false;
                        break;
                    }
                    else if (i == 2 && condition)
                        Console.WriteLine(searchName + "이 없습니다.");
                }
            }
        }
    }
}
