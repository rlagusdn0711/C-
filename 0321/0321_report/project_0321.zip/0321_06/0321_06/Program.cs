﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0321_06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1~99 사이의 정수를 입력하시오>>");
            string numm = Console.ReadLine();
            int num = Convert.ToInt32(numm);

            if (num != 0 && num >= 1 && num <= 99)
            {
                int a, b;
                a = num / 10;
                b = num % 10;

                if ((a == 3 || a == 6 || a == 9) && (b == 3 || b == 6 || b == 9))
                {
                    Console.WriteLine("박수짝짝");
                }
                else if ((a == 3 || a == 6 || a == 9) || (b == 3 || b == 6 || b == 9))
                {
                    Console.WriteLine("박수짝");
                }
            }
        }
    }
}
