﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0404_10
{
    class ArrayUtill
    {
        public static int[] concat(int[] a, int[] b)
        {
            int size = a.Length + b.Length;
            int [] concat = new int[size];
            for (int i = 0; i < a.Length; i++)
            {
                concat[i] = a[i];
            }
            for (int i = 0; i < b.Length; i++)
            {
                concat[i + a.Length] = b[i];
            }
            return concat;
        }
        public static void print(int[] a)
        {
            Console.Write("[ ");
            for (int i = 0; i < a.Length; i++)
            {
                Console.Write(a[i] + " ");
            }
            Console.Write(" ]");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array1 = { 1, 5, 7, 9 };
            int[] array2 = { 3, 6, -1, 100, 77 };
            int[] array3 = ArrayUtill.concat(array1, array2);
            ArrayUtill.print(array3);
        }
    }
}
