﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] n = new int[3, 3] { { 0, 0, 0, }, { 0, 0, 0 }, { 0, 0, 0 } };

            for (int i = 0; i < n.Length; i++)
            {
                for (int j = 0; j < n.GetLength(i); j++)
                {
                    Console.WriteLine(n[i,j] + " ");
                }
                Console.WriteLine("");
            }

        }
    }
}
