﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0321_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            string num=Console.ReadLine();
            int won=Convert.ToInt32(num);

            Console.WriteLine("오만원 " + won / 50000 + "개");
            won %=50000;
            Console.WriteLine("만원 " + won / 10000 + "개");
            won %=10000;
            Console.WriteLine("천원 " + won / 1000 + "개");
            won %=1000;
            Console.WriteLine("백원 " + won / 100 + "개");
            won %=100;
            Console.WriteLine("오십원 " + won / 50 + "개");
            won %=50;
            Console.WriteLine("십원 " + won / 10 + "개");
            won %=10;
            Console.WriteLine("일원 " + won / 1 + "개");
            won %=1;

        }
    }
}
