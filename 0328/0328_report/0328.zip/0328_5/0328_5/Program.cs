﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            int[] intArray=new int[10];
            for (int i = 0; i < 10; i++)
            {
                string numm = Console.ReadLine();
                int num=int.Parse(numm);

                intArray[i]=num;
            }
            Console.WriteLine();
            for (int i = 0; i < 10; i++)
            {
                if (intArray[i] % 3 == 0)
                {
                    Console.WriteLine(intArray[i] + " ");
                }
            }
        }
    }
}
