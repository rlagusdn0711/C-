﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i < 100; i++)
            {
                if (i > 10)
                {
                    int b = i % 10;
                    int a = (i - b) / 10;
                    if (a % 3 == 0 || a % 6 == 0 || a % 9 == 0)
                    {
                        if (b != 0 && (b % 3 == 0 || b % 6 == 0 || b % 9 == 0))
                        {
                            Console.WriteLine(i + " 박수 짝 짝");
                        }
                        else
                            Console.WriteLine(i + " 박수 짝");
                    }
                    else if (b != 0 && (b % 3 == 0 || b % 6 == 0 || b % 9 == 0))
                    {
                        Console.WriteLine(i + " 박수 짝");
                    }
                }
                else if (i % 3 == 0 || i % 6 == 0 || i % 9 == 0)
                {
                    Console.WriteLine(i + " 박수 짝");
                }
            }
        }
    }
}
