﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0321_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("두자리수 정수 입력 >>> ");
            string numm=Console.ReadLine(); 
            int num=Convert.ToInt32(numm);
            if(num%11==0)
            {
                Console.WriteLine("yes! 10의 자리와 1의 자리가 같습니다.");
            }
        }
    }
}
