﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0321_07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("점 (x,y)의 좌표를 입력하시오 >>");
            string xx = Console.ReadLine();
            int x = Convert.ToInt32(xx);
            string yy = Console.ReadLine();
            int y = Convert.ToInt32(yy);

            if ((100 <= x && x <= 200) && (100 <= y && y <= 200))
            {
                Console.WriteLine("(" + x + "," + y + ")는 사각형 안에 있습니다");
            }
        }
    }
}
