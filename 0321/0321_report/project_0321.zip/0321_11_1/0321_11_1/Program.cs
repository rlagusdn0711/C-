﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0321_11_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("달을 입력하세요(1~12)>>");
            string numm = Console.ReadLine();
            int num = Convert.ToInt32(numm);

            if(num == 3|| num == 4|| num == 5)
            {
                Console.WriteLine("봄");
            }
            else if (num == 6 || num == 7 || num == 8)
            {
                Console.WriteLine("여름");
            }
            else if (num == 9 || num == 10 || num == 11)
            {
                Console.WriteLine("가을");
            }
            else
            {
                Console.WriteLine("겨울");
            }
        }
    }
}
