﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0321_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("정수 3개 입력>>");
            string aa = Console.ReadLine();
            string bb = Console.ReadLine();
            string cc = Console.ReadLine();

            int a = Convert.ToInt32(aa);
            int b = Convert.ToInt32(bb);
            int c = Convert.ToInt32(cc);

            if (a < b && b < c || c < b && b < a)
            {
                Console.WriteLine("중간 값은" + b);
            }
            else if (b < a && a < c || c < a && a < b)
            {
                Console.WriteLine("중간 값은" + a);
            }
            else
            {
                Console.WriteLine("중간 값은" + c);
            }
        }
    }
}
