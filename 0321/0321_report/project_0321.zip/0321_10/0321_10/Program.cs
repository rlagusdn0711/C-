﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0321_10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("첫 번째 원의 중심과 반지름 입력>>");
            string xx = Console.ReadLine();
            int x = Convert.ToInt32(xx);
            string xx1 = Console.ReadLine();
            int x1 = Convert.ToInt32(xx1);
            string rr = Console.ReadLine();
            double r = Convert.ToDouble(rr);

            Console.WriteLine("두 번째 원의 중심과 반지름 입력>>");
            string yy = Console.ReadLine();
            int y = Convert.ToInt32(yy);
            string yy1 = Console.ReadLine();
            int y1 = Convert.ToInt32(yy1);
            string rr1 = Console.ReadLine();
            double r1 = Convert.ToDouble(rr1);

            double distance = 0;
            distance = Math.Sqrt((x - x1) * (x - x1) + (y - y1) * (y - y1));

            if (distance <= r + r1)
            {
                Console.WriteLine("두 원은 서로 겹친다.");
            }
        }
    }
}
