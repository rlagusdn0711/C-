﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0321_11_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("달을 입력하세요(1~12)>>");
            string numm = Console.ReadLine();
            int num = Convert.ToInt32(numm);

            switch (num)
            {
                case 3: case 4: case 5:
                    Console.WriteLine("봄");
                    break;
                case 6: case 7: case 8:
                    Console.WriteLine("여름");
                    break;
                case 9: case 10: case 11:
                    Console.WriteLine("가을");
                    break;
                case 12: case 1: case 2:
                    Console.WriteLine("겨울");
                    break;
            }
        }
    }
}
