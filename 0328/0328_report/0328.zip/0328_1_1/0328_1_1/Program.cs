﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_1_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int i = 0;

            while (i < 100)
            {
                sum = sum + i;
                i += 2;
            }
            Console.WriteLine(sum);
        }
    }
}
