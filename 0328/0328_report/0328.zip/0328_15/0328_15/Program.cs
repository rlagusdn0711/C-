﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("곱하고자 하는 두 수 입력 >> ");
                try
                {
                    string nn=Console.ReadLine();
                    string mm=Console.ReadLine();
                    int n=int.Parse(nn);
                    int m=int.Parse(mm);

                    Console.WriteLine(n + " x " + m + " = " + n * m);
                    break;
                }
                catch (Exception e)
                {
                    Console.WriteLine("실수는 입력하면 안됩니다.");
                }
            }
        }
    }
}
