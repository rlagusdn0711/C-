﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            int[] rndArray = new int[10];
            double sum = 0, regular = 0;
            for (int i = 0; i < 10; i++)
            {
                int rnd=rand.Next(10);
                rndArray[i] = rnd;
            }
            Console.WriteLine("랜덤한 정수들 : ");
            for (int i = 0; i < 10; i++)
            {
                Console.Write(rndArray[i] + " ");
                sum += rndArray[i];
            }
            regular = sum / 10.0;
            Console.WriteLine("평균은 " + regular);
        }
    }
}
