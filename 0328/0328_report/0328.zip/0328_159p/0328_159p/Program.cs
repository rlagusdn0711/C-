﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_159p
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            while (true)
            {
                int pc = r.Next(100);
                Console.WriteLine("수를 결정하였습니다. 맞추어보세요");

                int count = 1, max = 99, min = 0;
                String option = "";

                while (true)
                {
                    Console.WriteLine(min + "-" + max);
                    Console.Write(count + ">>");
                    string userr = Console.ReadLine();
                    int user=int.Parse(userr);

                    if (user > pc)
                    {
                        Console.WriteLine("더 낮게");
                        max = user;
                    }
                    else if (user < pc)
                    {
                        Console.WriteLine("더 높게");
                        min = user;
                    }
                    else
                    {
                        Console.WriteLine("맞았습니다.");
                        break;
                    }
                    count++;
                }
                Console.Write("다시하시겠습니까(y/n)>>");
                option = Console.ReadLine();

                if (option=="y") continue;
                else 
                    break;
            }

            Console.WriteLine("프로그램을 종료합니다.");
            return;
        }
    }
}
