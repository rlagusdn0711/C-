﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int avg = 0;
            string aa, bb, cc;
            aa = Console.ReadLine();
            bb = Console.ReadLine();
            cc = Console.ReadLine();
            int a = int.Parse(aa);
            int b = int.Parse(bb);
            int c = int.Parse(cc);

            sum = a + b + c;
            avg = sum / 3;

            Console.WriteLine(avg);
        }
    }
}
