﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0328_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            Console.WriteLine();
            string cntt;
            int j = 0;
            int rnd;
            cntt = Console.ReadLine();
            int cnt=int.Parse(cntt);
            int[] Array = new int[cnt];

            for (int i = 0; i < cnt; i++)
            {
                rnd=rand.Next(100);
                Array[i] = rnd;
                while (i > 0)
                {
                    if (Array[i] == Array[j])
                    {
                        rnd = rand.Next(100);
                        Array[i] = rnd;
                        j = 0;
                    }
                    j++;
                    if (i <= j)
                    {
                        j = 0;
                        break;
                    }
                }
            }
            for (int i = 0, k = 1; i < cnt; i++, k++)
            {
                Console.Write(Array[i] + "  ");
                if (k % 10 == 0)
                    Console.WriteLine("");
            }
        }
    }
}
