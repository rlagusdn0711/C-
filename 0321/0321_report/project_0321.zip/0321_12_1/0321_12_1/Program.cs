﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0321_12_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("연산>>");
            string numm1 = Console.ReadLine();
            int num1 = Convert.ToInt32(numm1);
            string op=Console.ReadLine();
            string numm2 = Console.ReadLine();
            int num2 = Convert.ToInt32(numm2);
            int res = 0;

            if(op=="+")
            {
                res = num1 + num2;
            }
            else if (op == "-")
            {
                res = num1 - num2;
            }
            else if (op == "*")
            {
                res = num1 * num2;
            }
            else if (op == "/")
            {
                res = num1 / num2;
            }

            Console.WriteLine(num1 + op + num2 + "의 계산결과는 " + res);
        }
    }
}
