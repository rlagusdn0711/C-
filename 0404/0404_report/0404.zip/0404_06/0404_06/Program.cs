﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0404_06
{
    internal class Program
    {
        class Circle
        {
            private double x, y;
            private int radius;
            public Circle(double x, double y, int radius)
            {
                this.x = x;
                this.y = y;
                this.radius = radius;
            }
            public int getRadius()
            {
                return radius;
            }
            public void show()
            {
                Console.WriteLine("가장 면적이 큰 원은 (" + x + "," + y + ")" + radius);
            }
        }
        static void Main(string[] args)
        {
            Circle [] c = new Circle[3];
            for (int i = 0; i < c.Length; i++)
            {
                Console.WriteLine("x, y, radius >> ");
                string xx = Console.ReadLine();
                string yy = Console.ReadLine();
                string rradius = Console.ReadLine();
                double x=double.Parse(xx);
                double y=double.Parse(yy);
                int radius = int.Parse(rradius);
                c[i] = new Circle(x, y, radius);
            }
            int max = 0, maxRadius = 0;
            for (int i = 0; i < c.Length; i++)
            {
                if (maxRadius < c[i].getRadius())
                {
                    maxRadius = c[i].getRadius();
                    max = i;
                }
            }
            c[max].show();
        }
    }
}
