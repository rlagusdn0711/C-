﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0404_09
{
    class Dictionary
    {
        private static String[] kor = { "사랑", "아기", "돈", "미래", "희망" };
        private static String[] eng = { "love", "baby", "money", "future", "hope" };
        public static String Kor2Eng(String word)
        {
            for (int i = 0; i < kor.Length; i++)
            {
                if (kor[i]==word)
                {
                    return word + "은 " + eng[i];
                }
            }
            return word + "는 저희 사전에 없습니다.";
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("한영 단어 검색 프로그램입니다.");
            while (true)
            {
                Console.WriteLine("한글 단어?");
                String word = Console.ReadLine();
                if (word=="그만") 
                    break;
                Console.WriteLine(Dictionary.Kor2Eng(word));
            }
        }
    }
}
