﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0321_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("원화를 입력하세요(단위 원 >>> )");
            string numm = Console.ReadLine();
            double num=Convert.ToDouble(numm);
            double dal=num/1100;
            Console.WriteLine(num + "원은 $" + dal + "입니다");

        }
    }
}
