﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0321_106p
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("가위바위보 게임입니다. 가위, 바위, 보 중에서 입력하세요.");
            Console.WriteLine("철수");
            string name_s = Console.ReadLine();
            Console.WriteLine("영희");
            string name_y = Console.ReadLine();

            if (name_s == "가위" & name_y == "가위")
            {
                Console.WriteLine("무승부입니다");
            }
            if (name_s == "가위" & name_y == "바위")
            {
                Console.WriteLine("영희가 이겼습니다");
            }
            if (name_s == "가위" & name_y == "보")
            {
                Console.WriteLine("철수가 이겼습니다");
            }
            if (name_s == "바위" & name_y == "가위")
            {
                Console.WriteLine("철수가 이겼습니다");
            }
            if (name_s == "바위" & name_y == "바위")
            {
                Console.WriteLine("무승부입니다");
            }
            if (name_s == "바위" & name_y == "보")
            {
                Console.WriteLine("영희가 이겼습니다");
            }
            if (name_s == "보" & name_y == "가위")
            {
                Console.WriteLine("영희가 이겼습니다");
            }
            if (name_s == "보" & name_y == "바위")
            {
                Console.WriteLine("철수가 이겼습니다");
            }
            if (name_s == "보" & name_y == "보")
            {
                Console.WriteLine("무승부입니다");
            }
        }
    }
}
